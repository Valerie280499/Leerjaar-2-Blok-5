/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzademo;

/**
 *
 * @author martijn
 */
public class PizzaDemo {

    public static void main(String[] args) {
    
        Pizza p1 = new Pizza();
        p1.setPrijs(10);
        p1.setNaam("Margerita");
        p1.setDiameter(40);
        Frisdrank f1 = new Frisdrank();
        f1.setPrijs(10);
        f1.setNaam("Cola");
        
        
    }
    
}
