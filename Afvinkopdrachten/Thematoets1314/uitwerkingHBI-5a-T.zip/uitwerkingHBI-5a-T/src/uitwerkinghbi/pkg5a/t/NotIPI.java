/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package uitwerkinghbi.pkg5a.t;

/**
 *
 * @author Martijn van der Bruggen (c) Hogeschool van Arnhem en Nijmegen
 *
 */
public class NotIPI extends Exception {

    NotIPI() {
        super();
    }
}
